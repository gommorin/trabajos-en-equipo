var buttonL = document.getElementsByClassName('btn btn-left')[0];

buttonL.onclick = function () {
    document.getElementById('box-wrapper').scrollLeft -= 250;
};

buttonR = document.getElementsByClassName('btn btn-right')[0];

buttonR.onclick = function () {
    document.getElementById('box-wrapper').scrollLeft += 250;
};


// FUNCIONES PARA GUARDAR AUTORES E INICIAR UN POST

const guardarAutor = () => {
    let title = $('#mediumTitle').val()
    let summary = $('#mediumSummary').val()
    let avatar = $('#mediumAvatar').val()
    let user = $('#mediumUser').val()
    let section = $('#mediumSection').val()
    let date = $('#mediumDate').val()
    let time = $('#mediumTime').val()
    let popular = $('#mediumPopular').val()
    let ranking = $('#mediumRanking').val()
    let editor  = $('#mediumEditor').val()
    let author = { title, summary, avatar, user, section, date, time, popular, ranking, editor }
    $.ajax({
            url:`https://ajaxclass9g.firebaseio.com/bell/medium/posts/.json`,
            method:"POST",
            data: JSON.stringify(author),
            success: ( response ) => {
                console.log("autor guardado");
                obtenerAutor();
            },
            error: ( error ) => {
                console.log("autor no guardado")
            }
        })
}

const obtenerAutor = () => {
    $.ajax({ 
        url:`https://ajaxclass9g.firebaseio.com/bell/medium/posts/.json`,
        method:"GET",
        success: ( response ) => {
            console.log( response )
            console.log("la respuesta del endpoint fue exitosa")
            let authors = response;
            $("#modalPost").empty();
            console.log("se borró el contenido del modal para empezar un post")
            for( postKey in authors ){
                console.log( authors[postKey] )
                let { title, summary, avatar, user, date, time } = authors[postKey]                
                $("#modalForm").hide();
                $("#modalPost").append(`
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="card">
                            <div class="card-body">
                                <div class="col-8 offset-2">
                                    <h1 class="card-title" id="card-title" id="postModalLabel">${title}</h5>
                                    <h3 class="card-subtitle mb-2 text-muted"id="card-">${summary}</h6>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <img src="${avatar}" class="rounded-circle dropdown-toggle" height="35px" type="button" alt="profile-avatar" id="dropdownAvatar" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <caption class="card-text" id="card-user">${user}</caption>
                                            <caption class="card-text" id="card-date">${date}</caption>
                                            <caption class="card-text" id="card-time">${time}</caption>
                                            <div id="popularity">
                                            </div>
                                        </div>
                                        <div>
                                            <a href="#" class="card-link">Compartir</a>
                                            <a href="#" class="card-link">Bookmark</a>
                                            <a href="#" class="card-link">More</a>
                                        </div>
                                    </div>
                                    <div>
                                        <textarea class="form-control" rows="10" id="writeContent" placeholder="Start typing"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                `)
            }
        }
    })
}

$('#postButton').click(guardarAutor)
obtenerAutor()